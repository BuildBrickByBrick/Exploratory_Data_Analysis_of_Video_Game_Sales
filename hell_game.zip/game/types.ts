export enum GameState {
  INTRO,
  FEAR_SELECTION,
  PLAYING,
  GAME_OVER
}

export enum Archetype {
  ANXIETY = 'ANXIETY',
  DEPRESSION = 'DEPRESSION',
  ANGER = 'ANGER',
  OVERTHINKING = 'OVERTHINKING',
  LONELINESS = 'LONELINESS',
  ADDICTION = 'ADDICTION',
  UNKNOWN = 'UNKNOWN'
}

export enum AIState {
  STALKING = 'STALKING',
  CHARGING = 'CHARGING',
  FLANKING = 'FLANKING',
  RETREATING = 'RETREATING',
  PANICKING = 'PANICKING'
}

export enum RewardType {
  HEALTH = 'HEALTH',
  ARMOR = 'ARMOR',
  AMMO = 'AMMO',
  SURGE = 'SURGE'
}

export enum BossPower {
  SHOCKWAVE = 'SHOCKWAVE',
  SUMMONER = 'SUMMONER',
  BLINKER = 'BLINKER',
  GRAVITY_WELL = 'GRAVITY_WELL'
}

export interface WeaponMod {
  id: string;
  name: string;
  description: string;
  stat: 'fireRate' | 'damage' | 'projectiles' | 'speed';
  multiplier: number;
}

export interface Weapon {
  name: string;
  fireRate: number;
  damage: number;
  projectiles: number;
  ammoType: string;
  currentAmmo: number;
  maxAmmo: number;
}

export interface PersonalityTraits {
  aggression: number;
  impulsiveness: number;
  persistence: number;
  awareness: number;
  cowardice: number;
  control: number;
  attachment: number;
  panicResponse: number;
  drainIntensity: number;
}

export interface FearConfig {
  name: string;
  archetype: Archetype;
  color: string;
  traits: PersonalityTraits;
  spawnRateMod: number;
}

export interface Entity {
  id: number;
  x: number;
  y: number;
  z?: number;
  angle?: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  hp: number;
  maxHp: number;
  armor: number;
  type: 'PLAYER' | 'ENEMY' | 'BULLET' | 'PARTICLE' | 'REWARD';
  rewardType?: RewardType;
  archetype?: Archetype;
  traits?: PersonalityTraits;
  state?: AIState;
  stateTimer?: number;
  noiseOffset?: number;
  selectedWeaponIndex?: number;
  teleportCooldown?: number; 
  isBuffed?: boolean; 
  floatOffset?: number;
  isBoss?: boolean;
  isMajorBoss?: boolean;
  bossPower?: BossPower;
  powerTimer?: number;
  shield?: number;
  maxShield?: number;
  shieldRegenTimer?: number;
  life?: number;
  maxLife?: number;
  flashTimer?: number;
  gravity?: number;
  phase?: number;
  isInvulnerable?: boolean;
  isDying?: boolean;
  deathTimer?: number;
  deathMaxTimer?: number;
  // Dismemberment state
  lostHead?: boolean;
  lostLeftArm?: boolean;
  lostRightArm?: boolean;
}

export const TILE_SIZE = 64;
export const MAP_SIZE = 32;