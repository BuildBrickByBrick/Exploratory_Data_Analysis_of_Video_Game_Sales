import { AudioEngine } from './audio';
import { Archetype, Entity, FearConfig, PersonalityTraits, AIState, Weapon, WeaponMod, RewardType, BossPower } from './types';

const RES_W = 320;
const RES_H = 200;
const HUD_H = 40;
const PLAY_H = RES_H - HUD_H;
const FOV = Math.PI / 3;
const BLOCK_SIZE = 64;
const MAP_DIM = 24;

const PALETTE = {
  SKY: '#080000',
  FLOOR: '#120805',
  WALL_DARK: '#2a1210',
  WALL_LIGHT: '#3d1a18',
  HUD_BG: '#1a1a1a',
  HUD_BORDER: '#333',
  HUD_ACCENT: '#900',
  TEXT_BRIGHT: '#fff',
  TEXT_RED: '#f00',
  REWARD_HEALTH: '#0f0',
  REWARD_ARMOR: '#0af',
  REWARD_AMMO: '#ff0',
  REWARD_SURGE: '#f0f',
  BOSS_COLOR: '#ff00ff',
  MAJOR_BOSS_COLOR: '#ff3300',
  BLOOD: '#800',
  BLOOD_BRIGHT: '#c00'
};

interface SpriteSheet {
  gunIdle: HTMLCanvasElement;
  gunFire: HTMLCanvasElement;
  anxietyZombie: HTMLCanvasElement[][][]; // Archetype -> Frame -> [Head, L-Arm, R-Arm] flags
  depressionZombie: HTMLCanvasElement[][][];
  angerZombie: HTMLCanvasElement[][][];
  overthinkingZombie: HTMLCanvasElement[][][];
  lonelinessZombie: HTMLCanvasElement[][][];
  addictionZombie: HTMLCanvasElement[][][];
  genericZombie: HTMLCanvasElement[][][];
  enemyEye: HTMLCanvasElement;
  rewardHealth: HTMLCanvasElement;
  rewardArmor: HTMLCanvasElement;
  rewardAmmo: HTMLCanvasElement;
  rewardSurge: HTMLCanvasElement;
  tankCannon: HTMLCanvasElement;
}

export class GameEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private audio: AudioEngine;
  private frameId: number = 0;
  private entities: Entity[] = [];
  private map: number[] = [];
  private lastTime: number = 0;
  private startTime: number = 0;
  private keys: Set<string> = new Set();
  private player: Entity | null = null;
  private score: number = 0;
  private intensity: number = 0; 
  private killCount: number = 0;
  private comboCount: number = 0;
  private comboTimer: number = 0;
  private comboMaxTime: number = 4.0;
  private surgeTimer: number = 0;
  private nextUpgradeScore: number = 200;
  private fearConfig: FearConfig;
  private onGameOver: (score: number) => void;
  private spawnTimer: number = 0;
  private trauma: number = 0;
  private zBuffer: number[] = new Array(RES_W).fill(0);
  private sprites: SpriteSheet;
  private fireTimer: number = 0;
  private gunBob: number = 0;
  private gunRecoil: number = 0;
  private gunFrame: number = 0;
  private debugMode: boolean = false;
  private traitInspector: boolean = false;
  private muzzleFlashTimer: number = 0;
  private screenShake: number = 0;
  private screenFlash: number = 0;
  
  private weapons: Weapon[] = [
    { name: 'SYMB-PISTOL', fireRate: 0.35, damage: 25, projectiles: 1, ammoType: 'SHELLS', currentAmmo: 50, maxAmmo: 100 },
    { name: 'SHATTER-GUN', fireRate: 0.85, damage: 18, projectiles: 8, ammoType: 'SHELLS', currentAmmo: 30, maxAmmo: 60 },
    { name: 'VOID-RIPPER', fireRate: 0.08, damage: 12, projectiles: 1, ammoType: 'VOLTS', currentAmmo: 200, maxAmmo: 400 },
    { name: 'HELL-BORE', fireRate: 0.6, damage: 180, projectiles: 1, ammoType: 'CORE', currentAmmo: 10, maxAmmo: 20 },
    { name: 'ABYSS-TANK', fireRate: 0.45, damage: 350, projectiles: 3, ammoType: 'ULTIMA', currentAmmo: 5, maxAmmo: 10 }
  ];
  private currentWeaponIdx: number = 0;
  private unlockedWeapons: number[] = [0];
  private floatingTexts: { x: number, y: number, text: string, timer: number, color: string }[] = [];

  constructor(canvas: HTMLCanvasElement, fearConfig: FearConfig, onGameOver: (score: number) => void) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false, desynchronized: true })!;
    this.fearConfig = fearConfig;
    this.onGameOver = onGameOver;
    this.audio = new AudioEngine();
    this.canvas.width = RES_W;
    this.canvas.height = RES_H;
    this.sprites = this.generateAssets();

    window.addEventListener('keydown', (e) => this.handleKeyDown(e));
    window.addEventListener('keyup', (e) => this.keys.delete(e.code));
    this.canvas.addEventListener('click', () => {
      this.canvas.requestPointerLock();
      this.audio.resume();
    });
    document.addEventListener('mousemove', (e) => this.handleMouseMove(e));
    document.addEventListener('mousedown', () => this.keys.add('MouseLeft'));
    document.addEventListener('mouseup', () => this.keys.delete('MouseLeft'));
  }

  private handleKeyDown(e: KeyboardEvent) {
    this.keys.add(e.code);
    if (e.code === 'Digit1' && this.unlockedWeapons.includes(0)) this.currentWeaponIdx = 0;
    if (e.code === 'Digit2' && this.unlockedWeapons.includes(1)) this.currentWeaponIdx = 1;
    if (e.code === 'Digit3' && this.unlockedWeapons.includes(2)) this.currentWeaponIdx = 2;
    if (e.code === 'Digit4' && this.unlockedWeapons.includes(3)) this.currentWeaponIdx = 3;
    if (e.code === 'Digit5' && this.unlockedWeapons.includes(4)) this.currentWeaponIdx = 4;
    if (e.code === 'Backquote') this.debugMode = !this.debugMode;
    if (e.code === 'KeyV') this.traitInspector = !this.traitInspector;
  }

  private generateAssets(): SpriteSheet {
    const create = (w: number, h: number) => {
      const c = document.createElement('canvas');
      c.width = w; c.height = h;
      return c;
    };

    const gunIdle = create(64, 64);
    const gCtx = gunIdle.getContext('2d')!;
    gCtx.fillStyle = '#111'; gCtx.fillRect(24, 20, 16, 44); 
    gCtx.fillStyle = '#333'; gCtx.fillRect(20, 45, 24, 15);

    const gunFire = create(64, 64);
    const fCtx = gunFire.getContext('2d')!;
    fCtx.drawImage(gunIdle, 0, 0);
    fCtx.fillStyle = '#ffaa00'; fCtx.beginPath(); fCtx.arc(32, 15, 15, 0, Math.PI*2); fCtx.fill();
    fCtx.fillStyle = '#fff'; fCtx.beginPath(); fCtx.arc(32, 15, 8, 0, Math.PI*2); fCtx.fill();

    const tankCannon = create(128, 128);
    const tCtx = tankCannon.getContext('2d')!;
    tCtx.fillStyle = '#1a1a1a'; tCtx.fillRect(40, 60, 48, 60);
    tCtx.fillStyle = '#222'; tCtx.fillRect(20, 80, 88, 40);
    tCtx.fillStyle = '#444'; tCtx.fillRect(44, 10, 15, 70);
    tCtx.fillRect(69, 10, 15, 70);
    tCtx.fillStyle = '#900'; tCtx.fillRect(30, 90, 68, 10);

    const rewardHealth = create(32, 32); this.drawReward(rewardHealth.getContext('2d')!, PALETTE.REWARD_HEALTH);
    const rewardArmor = create(32, 32); this.drawReward(rewardArmor.getContext('2d')!, PALETTE.REWARD_ARMOR);
    const rewardAmmo = create(32, 32); this.drawReward(rewardAmmo.getContext('2d')!, PALETTE.REWARD_AMMO);
    const rewardSurge = create(32, 32); this.drawReward(rewardSurge.getContext('2d')!, PALETTE.REWARD_SURGE);

    const generateFrames = (skin: string, accent: string) => {
        // [frameIndex][lostHead ? 1 : 0][lostLeftArm ? 1 : 0][lostRightArm ? 1 : 0]
        const archetypes = [];
        for (let f = 0; f < 2; f++) {
            const headVars = [];
            for (let h = 0; h < 2; h++) {
                const lArmVars = [];
                for (let la = 0; la < 2; la++) {
                    const rArmVars = [];
                    for (let ra = 0; ra < 2; ra++) {
                        const canvas = create(32, 32);
                        this.drawDetailedZombie(canvas.getContext('2d')!, skin, accent, f, !!h, !!la, !!ra);
                        rArmVars.push(canvas);
                    }
                    lArmVars.push(rArmVars);
                }
                headVars.push(lArmVars);
            }
            archetypes.push(headVars);
        }
        return archetypes;
    };

    const enemyEye = create(32, 32);
    const yCtx = enemyEye.getContext('2d')!;
    yCtx.fillStyle = '#f00'; yCtx.fillRect(14, 10, 4, 3);

    return { 
      gunIdle, gunFire, 
      anxietyZombie: generateFrames('#4f8', '#ff0'), 
      depressionZombie: generateFrames('#78a', '#ff0'), 
      angerZombie: generateFrames('#b44', '#f22'), 
      overthinkingZombie: generateFrames('#c8f', '#fff'), 
      lonelinessZombie: generateFrames('#ccc', '#fff'), 
      addictionZombie: generateFrames('#6a6', '#0f0'), 
      genericZombie: generateFrames('#897', '#fff'), 
      enemyEye,
      rewardHealth, rewardArmor, rewardAmmo, rewardSurge, tankCannon
    };
  }

  private drawDetailedZombie(ctx: CanvasRenderingContext2D, skinColor: string, accentColor: string, frame: number, noHead: boolean, noLArm: boolean, noRArm: boolean) {
    const P = 2; 
    const drawPixel = (x: number, y: number, color: string) => { 
        ctx.fillStyle = color; 
        ctx.fillRect(x * P, y * P, P, P); 
    };
    
    let shirtColor = '#f0f0f0'; 
    let pantsColor = '#245';   
    if (skinColor === '#78a') { shirtColor = '#d72'; pantsColor = '#564'; } 
    else if (skinColor === '#b44') { shirtColor = '#111'; pantsColor = '#300'; }

    // Head
    if (!noHead) {
        for(let x=6; x<=10; x++) for(let y=1; y<=6; y++) drawPixel(x,y, skinColor);
        drawPixel(5, 3, skinColor); drawPixel(11, 3, skinColor); 
        drawPixel(6, 1, '#121'); 
        drawPixel(7, 3, accentColor); drawPixel(9, 3, accentColor);
        ctx.fillStyle = '#100'; ctx.fillRect(7*P, 5*P, 3*P, 2*P);
        drawPixel(7, 6, '#fff'); drawPixel(9, 6, '#fff'); 
    } else {
        // bloody stump
        drawPixel(7, 6, PALETTE.BLOOD); drawPixel(8, 6, PALETTE.BLOOD_BRIGHT); drawPixel(9, 6, PALETTE.BLOOD);
    }

    // Torso
    for(let x=5; x<=11; x++) for(let y=7; y<=11; y++) drawPixel(x,y, shirtColor);
    
    // ARMS
    const armYOffset = frame === 0 ? 0 : 1;
    if (!noLArm) {
        drawPixel(4, 7, shirtColor); drawPixel(3, 7, shirtColor);
        drawPixel(2, 7 + armYOffset, skinColor); drawPixel(1, 7 + armYOffset, skinColor); 
    } else {
        drawPixel(4, 7, PALETTE.BLOOD);
    }
    
    if (!noRArm) {
        drawPixel(12, 8, shirtColor);
        drawPixel(12, 9 - armYOffset, skinColor); drawPixel(12, 10 - armYOffset, skinColor); 
    } else {
        drawPixel(12, 8, PALETTE.BLOOD);
    }

    // Legs
    for(let x=6; x<=10; x++) for(let y=12; y<=14; y++) drawPixel(x,y, pantsColor);
    if (frame === 0) {
        drawPixel(6, 15, skinColor); drawPixel(5, 15, skinColor);
        drawPixel(10, 14, skinColor); drawPixel(11, 14, skinColor);
    } else {
        drawPixel(6, 14, skinColor); drawPixel(5, 14, skinColor);
        drawPixel(10, 15, skinColor); drawPixel(11, 15, skinColor);
    }
  }

  private drawReward(ctx: CanvasRenderingContext2D, color: string) {
    ctx.fillStyle = color; ctx.beginPath(); ctx.arc(16, 16, 10, 0, Math.PI*2); ctx.fill();
    ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.stroke();
  }

  private handleMouseMove(e: MouseEvent) {
    if (document.pointerLockElement === this.canvas && this.player) {
      this.player.angle = (this.player.angle || 0) + e.movementX * 0.003;
    }
  }

  start() {
    this.initWorld();
    this.audio.playStartSound();
    this.startTime = performance.now();
    this.lastTime = this.startTime;
    this.loop(this.lastTime);
  }

  stop() { cancelAnimationFrame(this.frameId); }

  private initWorld() {
    this.entities = []; this.score = 0; this.killCount = 0; this.intensity = 0; this.comboCount = 0; this.comboTimer = 0;
    this.unlockedWeapons = [0]; this.currentWeaponIdx = 0; this.nextUpgradeScore = 200;
    this.map = new Array(MAP_DIM * MAP_DIM).fill(0);
    for (let y = 0; y < MAP_DIM; y++) {
      for (let x = 0; x < MAP_DIM; x++) {
        if (x === 0 || x === MAP_DIM - 1 || y === 0 || y === MAP_DIM - 1 || Math.random() > 0.94) {
          this.map[y * MAP_DIM + x] = 1;
        }
      }
    }
    this.player = {
      id: 0, x: MAP_DIM * BLOCK_SIZE / 2, y: MAP_DIM * BLOCK_SIZE / 2,
      angle: 0, vx: 0, vy: 0, radius: 16, color: '#fff', hp: 100, maxHp: 100, armor: 100, type: 'PLAYER'
    };
    this.entities.push(this.player);
  }

  private loop(time: number) {
    const dt = Math.min((time - this.lastTime) / 1000, 0.1);
    this.lastTime = time;
    this.update(dt);
    this.draw();
    this.frameId = requestAnimationFrame((t) => this.loop(t));
  }

  private updateIntensity() {
    const elapsed = (this.lastTime - this.startTime) / 1000;
    this.intensity = Math.min(25, (this.score / 1500) + (elapsed / 45) + (this.killCount / 12));
  }

  private spawnParticles(x: number, y: number, color: string, count: number, speed: number = 100, spread: number = Math.PI * 2, dir: number = 0, gravity: number = 400) {
    for (let i = 0; i < count; i++) {
        const angle = dir + (Math.random() - 0.5) * spread;
        const s = Math.random() * speed + speed * 0.5;
        this.entities.push({
            id: Math.random(), x, y, vx: Math.cos(angle) * s, vy: Math.sin(angle) * s, radius: 1.5 + Math.random() * 2, color,
            hp: 1, maxHp: 1, armor: 0, type: 'PARTICLE', life: 0.3 + Math.random() * 0.8, maxLife: 1.1, gravity: gravity + Math.random() * 100
        });
    }
  }

  private update(dt: number) {
    if (!this.player) return;
    this.updateIntensity();

    if (this.score >= this.nextUpgradeScore && this.unlockedWeapons.length < 5) {
        this.triggerUpgrade(this.unlockedWeapons.length);
        this.nextUpgradeScore += 450 + (this.unlockedWeapons.length * 200);
    }

    if (this.comboTimer > 0) {
      this.comboTimer -= dt;
      if (this.comboTimer <= 0) this.comboCount = 0;
    }
    if (this.surgeTimer > 0) this.surgeTimer -= dt;
    if (this.muzzleFlashTimer > 0) this.muzzleFlashTimer -= dt;
    if (this.screenShake > 0) this.screenShake = Math.max(0, this.screenShake - dt * 15);
    if (this.gunRecoil > 0) this.gunRecoil = Math.max(0, this.gunRecoil - dt * 8);
    if (this.screenFlash > 0) this.screenFlash = Math.max(0, this.screenFlash - dt * 2);

    for (let i = this.entities.length - 1; i >= 0; i--) {
      const e = this.entities[i];
      if (e.type === 'PLAYER') continue;

      if (e.isDying) {
          e.deathTimer! -= dt;
          if (e.isMajorBoss && Math.random() < 0.2) {
              this.audio.playExplosion();
              this.spawnParticles(e.x + (Math.random()-0.5)*150, e.y + (Math.random()-0.5)*150, e.color, 10, 150);
          }
          continue;
      }

      if (e.type === 'PARTICLE') {
          e.life! -= dt;
          e.vy += (e.gravity || 0) * dt; 
          e.x += e.vx * dt; e.y += e.vy * dt;
          e.vx *= 0.98; e.vy *= 0.98;
          if (e.life! <= 0) this.entities.splice(i, 1);
          continue;
      }

      if (e.type === 'REWARD') {
        const d = Math.sqrt((e.x-this.player.x)**2 + (e.y-this.player.y)**2);
        if (d < 30) {
            this.collectReward(e);
            this.entities.splice(i, 1);
        }
        continue;
      }

      if (e.type === 'ENEMY') {
        const dx = this.player.x - e.x; const dy = this.player.y - e.y; const dist = Math.sqrt(dx*dx + dy*dy);
        const neighbors = this.entities.filter(ne => ne.type === 'ENEMY' && ne.id !== e.id && Math.sqrt((ne.x-e.x)**2+(ne.y-e.y)**2) < 150);
        if (neighbors.length >= 2 && e.state !== AIState.CHARGING) {
            e.state = AIState.CHARGING; e.stateTimer = 2.0;
        }

        if (!e.state || (e.stateTimer && e.stateTimer <= 0)) this.decideNextState(e, e.traits!);
        if (e.stateTimer) e.stateTimer -= dt;
        if (e.flashTimer && e.flashTimer > 0) e.flashTimer -= dt;

        let baseSpeed = (60 + this.intensity * 15) * (0.6 + e.traits!.aggression * 0.9);
        if (e.isBoss) baseSpeed *= 0.8;
        if (e.lostHead) baseSpeed *= 0.5; // Brainless zombies are slower

        let targetVx = dx/dist; let targetVy = dy/dist;
        if (e.state === AIState.FLANKING) {
            const side = (e.noiseOffset || 0) > 500 ? 1 : -1;
            targetVx = (-dy/dist) * side * 1.2 + (dx/dist) * 0.1;
            targetVy = (dx/dist) * side * 1.2 + (dy/dist) * 0.1;
        }

        if (!this.checkCollision(e.x + targetVx * baseSpeed * dt, e.y + targetVy * baseSpeed * dt)) {
            e.x += targetVx * baseSpeed * dt; e.y += targetVy * baseSpeed * dt;
        }

        if (dist < 40 && this.surgeTimer <= 0) { 
            this.damagePlayer(45 * e.traits!.aggression * dt); 
            this.trauma = Math.min(this.trauma + 35 * dt, 50); 
            this.screenShake = Math.max(this.screenShake, 3);
        }
      } else if (e.type === 'BULLET') {
          e.x += e.vx * dt; e.y += e.vy * dt;
          if (this.checkCollision(e.x, e.y)) { 
              this.entities.splice(i, 1); 
              continue; 
          }
          for (const target of this.entities) {
            if (target.type === 'ENEMY' && !target.isDying) {
                const d = Math.sqrt((e.x-target.x)**2 + (e.y-target.y)**2);
                if (d < (target.isBoss ? 75 : 38)) {
                    target.flashTimer = 0.08;
                    const hitAngle = Math.atan2(-e.vy, -e.vx);
                    target.hp -= e.hp;
                    
                    // DISASSEMBLY LOGIC based on projectile impact
                    // Since it's 2D raycasting, we check vertical alignment in the sprite space later,
                    // but we can simulate it by random chance or impact force.
                    const disassemblyChance = 0.4;
                    if (Math.random() < disassemblyChance) {
                        const r = Math.random();
                        if (r < 0.2 && !target.lostHead) {
                            target.lostHead = true;
                            this.spawnParticles(target.x, target.y, target.color, 12, 100, Math.PI/2, Math.PI/2);
                        } else if (r < 0.5 && !target.lostLeftArm) {
                            target.lostLeftArm = true;
                            this.spawnParticles(target.x, target.y, target.color, 8, 80, Math.PI/2, hitAngle);
                        } else if (r < 0.8 && !target.lostRightArm) {
                            target.lostRightArm = true;
                            this.spawnParticles(target.x, target.y, target.color, 8, 80, Math.PI/2, hitAngle);
                        }
                    }

                    this.spawnParticles(e.x, e.y, PALETTE.BLOOD_BRIGHT, 8, 120, Math.PI/2, hitAngle);
                    this.audio.playHit();
                    if (target.hp <= 0) this.onEnemyKilled(target);
                    this.entities.splice(i, 1); break;
                }
            }
          }
      }
    }

    let pSpd = 210 * dt * (this.surgeTimer > 0 ? 1.9 : 1.0);
    const cosA = Math.cos(this.player.angle!); const sinA = Math.sin(this.player.angle!);
    if (this.keys.has('KeyW')) this.pMove(cosA * pSpd, sinA * pSpd);
    if (this.keys.has('KeyS')) this.pMove(-cosA * pSpd, -sinA * pSpd);
    if (this.keys.has('KeyA')) this.pMove(sinA * pSpd, -cosA * pSpd);
    if (this.keys.has('KeyD')) this.pMove(-sinA * pSpd, cosA * pSpd);

    if (this.fireTimer > 0) this.fireTimer -= dt;
    if (this.gunFrame > 0) this.gunFrame--;
    if (this.keys.has('MouseLeft') && this.fireTimer <= 0) this.fireWeapon();

    this.spawnTimer += dt;
    const maxEnemies = Math.floor(4 + this.intensity * 2.5);
    if (this.spawnTimer > (2.2 / this.fearConfig.spawnRateMod) && this.entities.filter(e => e.type === 'ENEMY' && !e.isDying).length < maxEnemies) {
        this.spawnEnemy(); this.spawnTimer = 0;
    }

    this.entities = this.entities.filter(e => {
        if (e.type === 'PLAYER') return true;
        if (e.type === 'PARTICLE') return e.life! > 0;
        if (e.isDying) return e.deathTimer! > 0;
        return e.hp > 0;
    });
    
    this.trauma = Math.max(0, this.trauma - dt * 25);
    if (this.player.hp <= 0) { document.exitPointerLock(); this.onGameOver(this.score); this.stop(); }
  }

  private onEnemyKilled(enemy: Entity) {
    this.killCount++; this.comboCount++; this.comboTimer = this.comboMaxTime;
    this.score += (enemy.isBoss ? 5000 : 150);
    this.audio.playDeathSquelch();
    this.screenShake = Math.max(this.screenShake, enemy.isBoss ? 15 : 4);
    
    enemy.hp = 0; enemy.isDying = true;
    enemy.deathMaxTimer = enemy.isMajorBoss ? 2.5 : 0.6;
    enemy.deathTimer = enemy.deathMaxTimer;
    
    this.spawnParticles(enemy.x, enemy.y, PALETTE.BLOOD, 25, 180);
    this.spawnParticles(enemy.x, enemy.y, enemy.color, 15, 150);

    if (this.killCount % 20 === 0 && !enemy.isMajorBoss) this.spawnBoss(true);
    
    // CONSISTENT REWARDS: Health and Ammo drops
    const dropChance = 0.5;
    if (Math.random() < dropChance) {
        this.spawnReward(enemy.x, enemy.y);
    }
  }

  private triggerUpgrade(idx: number) {
    if (this.unlockedWeapons.includes(idx)) return;
    this.unlockedWeapons.push(idx);
    this.currentWeaponIdx = idx;
    this.screenFlash = 1.0;
    this.audio.playStartSound();
    this.floatingTexts.push({ x: RES_W/2, y: PLAY_H/2, text: `ARSENAL EVOLVED: ${this.weapons[idx].name}`, timer: 3.0, color: '#fc0' });
  }

  private spawnBoss(major: boolean) {
    if (!this.player) return;
    this.audio.playStartSound();
    let ex, ey;
    do { ex = Math.random() * MAP_DIM * BLOCK_SIZE; ey = Math.random() * MAP_DIM * BLOCK_SIZE; } while(this.checkCollision(ex, ey) || Math.sqrt((ex-this.player.x)**2+(ey-this.player.y)**2) < 300);
    this.entities.push({
        id: Math.random(), x: ex, y: ey, vx: 0, vy: 0, radius: 75, color: PALETTE.MAJOR_BOSS_COLOR,
        hp: 2500, maxHp: 2500, armor: 400, type: 'ENEMY', isBoss: true, isMajorBoss: true,
        traits: { aggression: 0.9, impulsiveness: 0.7, persistence: 1.0, awareness: 1.0, cowardice: 0, control: 0.8, attachment: 1.0, panicResponse: 0, drainIntensity: 0.9 }
    });
  }

  private spawnReward(x: number, y: number) {
    const types = [RewardType.HEALTH, RewardType.AMMO];
    const type = types[Math.floor(Math.random() * types.length)];
    this.entities.push({ id: Math.random(), x, y, vx: 0, vy: 0, radius: 14, hp: 1, maxHp: 1, armor: 0, color: '#fff', type: 'REWARD', rewardType: type });
  }

  private collectReward(e: Entity) {
    if (!this.player) return;
    if (e.rewardType === RewardType.HEALTH) { 
      this.audio.playStartSound();
      this.player.hp = Math.min(100, this.player.hp + 20); 
      this.floatingTexts.push({x: RES_W/2, y: PLAY_H/2, text: "+HEALTH", timer: 1, color: PALETTE.REWARD_HEALTH}); 
    }
    else if (e.rewardType === RewardType.AMMO) { 
      this.audio.playAmmoPickup();
      const w = this.weapons[this.currentWeaponIdx]; 
      w.currentAmmo = Math.min(w.maxAmmo, w.currentAmmo + 15); 
      this.floatingTexts.push({x: RES_W/2, y: PLAY_H/2, text: "+AMMO", timer: 1, color: PALETTE.REWARD_AMMO}); 
    }
  }

  private fireWeapon() {
    if (!this.player || this.weapons[this.currentWeaponIdx].currentAmmo <= 0) return;
    const w = this.weapons[this.currentWeaponIdx]; w.currentAmmo--; this.fireTimer = w.fireRate; this.gunFrame = 6; this.muzzleFlashTimer = 0.08;
    this.gunRecoil = 5.0;
    this.screenShake = Math.max(this.screenShake, this.currentWeaponIdx > 3 ? 8.0 : 1.5);
    this.audio.playShoot(this.currentWeaponIdx);
    
    const angle = this.player.angle!;
    const projCount = w.projectiles;
    for (let i = 0; i < projCount; i++) {
        const spreadAngle = (i - (projCount - 1) / 2) * 0.15;
        this.entities.push({ 
            id: Math.random(), x: this.player.x, y: this.player.y, 
            vx: Math.cos(angle + spreadAngle) * 850, vy: Math.sin(angle + spreadAngle) * 850, 
            radius: 5, color: '#ff0', hp: w.damage, maxHp: 1, armor: 0, type: 'BULLET' 
        });
    }
  }

  private damagePlayer(amt: number) {
    this.screenShake = Math.max(this.screenShake, 4.0);
    this.trauma = Math.min(50, this.trauma + amt * 0.5);
    if (this.player!.armor > 0) { this.player!.armor -= amt * 0.45; this.player!.hp -= amt * 0.55; } else { this.player!.hp -= amt; }
  }

  private decideNextState(e: Entity, t: PersonalityTraits) {
    const r = Math.random();
    if (this.comboCount > 5) {
        e.state = r < 0.7 ? AIState.CHARGING : AIState.FLANKING;
    } else {
        if (r < t.aggression) e.state = AIState.CHARGING;
        else if (r < t.aggression + t.awareness) e.state = AIState.FLANKING;
        else e.state = AIState.STALKING;
    }
    e.stateTimer = 0.8 + Math.random() * 1.8;
  }

  private pMove(dx: number, dy: number) {
    if (!this.checkCollision(this.player!.x + dx, this.player!.y)) this.player!.x += dx;
    if (!this.checkCollision(this.player!.x, this.player!.y + dy)) this.player!.y += dy;
    this.gunBob += 0.42;
  }

  private checkCollision(x: number, y: number) {
    const mx = Math.floor(x/BLOCK_SIZE); const my = Math.floor(y/BLOCK_SIZE);
    return mx < 0 || mx >= MAP_DIM || my < 0 || my >= MAP_DIM || this.map[my*MAP_DIM + mx] === 1;
  }

  private spawnEnemy() {
    let ex, ey;
    do { ex = Math.random() * MAP_DIM * BLOCK_SIZE; ey = Math.random() * MAP_DIM * BLOCK_SIZE; } while(this.checkCollision(ex, ey) || Math.sqrt((ex-this.player!.x)**2+(ey-this.player!.y)**2) < 200);
    this.entities.push({ id: Math.random(), x: ex, y: ey, vx: 0, vy: 0, radius: 24, color: this.fearConfig.color, hp: 70 + this.intensity * 5, maxHp: 70 + this.intensity * 5, armor: 0, type: 'ENEMY', archetype: this.fearConfig.archetype, traits: { ...this.fearConfig.traits }, noiseOffset: Math.random()*1000 });
  }

  private draw() {
    const shakeX = (Math.random()-0.5) * this.screenShake;
    const shakeY = (Math.random()-0.5) * this.screenShake;
    const traumaX = (Math.random()-0.5) * this.trauma * 0.4 + shakeX;
    const traumaY = (Math.random()-0.5) * this.trauma * 0.4 + shakeY;

    this.ctx.fillStyle = PALETTE.SKY; this.ctx.fillRect(0, 0, RES_W, PLAY_H/2);
    this.ctx.fillStyle = PALETTE.FLOOR; this.ctx.fillRect(0, PLAY_H/2, RES_W, PLAY_H/2);
    
    this.castRays(traumaX, traumaY); 
    this.drawSprites(traumaX, traumaY); 
    this.drawWeapon(traumaX, traumaY);
    this.drawDashboard();
    
    if (this.muzzleFlashTimer > 0) {
        this.ctx.fillStyle = `rgba(255, 200, 50, ${this.currentWeaponIdx === 4 ? 0.3 : 0.1})`;
        this.ctx.fillRect(0,0, RES_W, PLAY_H);
    }
    
    if (this.screenFlash > 0) {
        this.ctx.fillStyle = `rgba(255, 255, 255, ${this.screenFlash * 0.8})`;
        this.ctx.fillRect(0,0, RES_W, PLAY_H);
        this.screenFlash -= 0.05; 
    }

    for (let i = this.floatingTexts.length - 1; i >= 0; i--) {
        const ft = this.floatingTexts[i];
        this.ctx.fillStyle = ft.color;
        this.ctx.font = '12px "Share Tech Mono"';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(ft.text, ft.x, ft.y);
        ft.timer -= 0.016;
        ft.y -= 0.5;
        if (ft.timer <= 0) this.floatingTexts.splice(i, 1);
    }
  }

  private castRays(tx: number, ty: number) {
    let angle = this.player!.angle! - FOV/2;
    for (let i = 0; i < RES_W; i++) {
        const cos = Math.cos(angle); const sin = Math.sin(angle);
        let dist = 0; let hit = false;
        while (!hit && dist < 18) { dist += 0.05; if (this.checkCollision(this.player!.x + cos * dist * BLOCK_SIZE, this.player!.y + sin * dist * BLOCK_SIZE)) hit = true; }
        dist *= Math.cos(this.player!.angle! - angle); this.zBuffer[i] = dist * BLOCK_SIZE;
        const h = RES_H / dist;
        this.ctx.fillStyle = hit ? PALETTE.WALL_LIGHT : PALETTE.WALL_DARK;
        this.ctx.fillRect(i + tx, (PLAY_H - h)/2 + ty, 1, h);
        angle += FOV/RES_W;
    }
  }

  private drawSprites(tx: number, ty: number) {
    const sorted = this.entities.filter(e => e.type !== 'PLAYER' && e.type !== 'BULLET').map(e => ({ e, d: Math.sqrt((e.x-this.player!.x)**2 + (e.y-this.player!.y)**2) })).sort((a,b) => b.d - a.d);
    const spriteMap: any = {
      [Archetype.ANXIETY]: this.sprites.anxietyZombie,
      [Archetype.DEPRESSION]: this.sprites.depressionZombie,
      [Archetype.ANGER]: this.sprites.angerZombie,
      [Archetype.OVERTHINKING]: this.sprites.overthinkingZombie,
      [Archetype.LONELINESS]: this.sprites.lonelinessZombie,
      [Archetype.ADDICTION]: this.sprites.addictionZombie,
    };
    const frameIndex = Math.floor(this.lastTime / 200) % 2;

    for (const s of sorted) {
        const e = s.e; let diff = Math.atan2(e.y - this.player!.y, e.x - this.player!.x) - this.player!.angle!;
        while (diff < -Math.PI) diff += Math.PI*2; while (diff > Math.PI) diff -= Math.PI*2;
        if (Math.abs(diff) > FOV) continue;
        const dist = s.d * Math.cos(diff); const sx = (0.5 * (1 + Math.tan(diff) / Math.tan(FOV/2))) * RES_W;
        const h = Math.abs(RES_H / (dist / BLOCK_SIZE));
        if (sx < 0 || sx >= RES_W || this.zBuffer[Math.floor(sx)] < dist - 10) continue;
        
        this.ctx.save();
        let localTx = sx + tx; let localTy = (PLAY_H - h)/2 + h/2 + ty;
        let scaleX = 1; let scaleY = 1; let alpha = 1.0;

        if (e.isDying) {
            const progress = 1 - (e.deathTimer! / e.deathMaxTimer!);
            alpha = 1 - progress;
            scaleX = scaleY = 1 + progress;
        }

        this.ctx.translate(localTx, localTy);
        this.ctx.globalAlpha = alpha;
        this.ctx.scale(scaleX, scaleY);

        if (e.type === 'PARTICLE') { 
            this.ctx.fillStyle = e.color; 
            const pSize = Math.max(1, (e.life! / e.maxLife!) * h / 10);
            this.ctx.fillRect(-pSize/2, -pSize/2, pSize, pSize); 
        } else if (e.type === 'ENEMY') {
            if (e.flashTimer && e.flashTimer > 0) this.ctx.filter = 'brightness(5)';
            const archeFrames = spriteMap[e.archetype!] || this.sprites.genericZombie;
            
            // Map disassembly state to frame selection
            const hIdx = e.lostHead ? 1 : 0;
            const laIdx = e.lostLeftArm ? 1 : 0;
            const raIdx = e.lostRightArm ? 1 : 0;
            const sprite = archeFrames[frameIndex][hIdx][laIdx][raIdx];
            
            this.ctx.drawImage(sprite, -h/2, -h/2, h, h);
            if (this.traitInspector && !e.isDying) {
                this.ctx.resetTransform();
                this.ctx.translate(localTx + h/2, localTy - h/2);
                this.ctx.fillStyle = '#0f0'; this.ctx.font = '6px monospace';
                this.ctx.fillText(`AGR:${e.traits!.aggression.toFixed(1)}`, 0, 0);
            }
        } else if (e.type === 'REWARD') {
            const sprite = e.rewardType === RewardType.HEALTH ? this.sprites.rewardHealth : this.sprites.rewardAmmo;
            this.ctx.drawImage(sprite, -h/2, -h/2, h, h);
        }
        this.ctx.restore();
    }
  }

  private drawWeapon(tx: number, ty: number) {
    const isTank = this.currentWeaponIdx === 4;
    const bx = Math.cos(this.gunBob)*10; 
    const by = Math.abs(Math.sin(this.gunBob))*10 + this.gunRecoil * 15;
    const size = isTank ? 280 : 136;
    this.ctx.save();
    this.ctx.translate(RES_W/2 + bx + tx, PLAY_H - (isTank ? 180 : 70) + by + ty);
    const sprite = this.gunFrame > 0 ? this.sprites.gunFire : (isTank ? this.sprites.tankCannon : this.sprites.gunIdle);
    this.ctx.drawImage(sprite, -size/2, -size/2, size, size);
    this.ctx.restore();
  }

  private drawDashboard() {
    const y = PLAY_H; this.ctx.fillStyle = PALETTE.HUD_BG; this.ctx.fillRect(0, y, RES_W, HUD_H);
    const w = this.weapons[this.currentWeaponIdx];
    this.drawStat('AMMO', `${w.currentAmmo}`, 2, 45, w.currentAmmo < 5 ? '#f33' : '#fff');
    this.drawStat('LIFE', `${Math.ceil(this.player!.hp)}%`, 49, 55, this.player!.hp < 30 ? '#f33' : '#fff');
    this.drawStat('WILL', `${this.score}`, 106, 50, '#fc0');
    this.drawStat('COMBO', `x${this.comboCount}`, 158, 40, this.comboCount > 5 ? '#f0f' : '#fff');
    this.drawStat('TIER', `${this.currentWeaponIdx + 1}`, 200, 30, '#0af');
  }

  private drawStat(label: string, val: string, x: number, w: number, color: string) {
    this.ctx.fillStyle = 'rgba(0,0,0,0.7)'; this.ctx.fillRect(x, PLAY_H+5, w, HUD_H-10);
    this.ctx.fillStyle = '#999'; this.ctx.font = '8px "Share Tech Mono"'; this.ctx.textAlign = 'center'; this.ctx.fillText(label, x + w/2, PLAY_H + 13);
    this.ctx.fillStyle = color; this.ctx.font = '14px "Share Tech Mono"'; this.ctx.fillText(val, x + w/2, PLAY_H + 34);
  }
}