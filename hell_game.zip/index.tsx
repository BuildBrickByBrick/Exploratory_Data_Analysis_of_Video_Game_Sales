import React, { useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { GoogleGenAI, Type } from "@google/genai";
import { GameEngine } from './game/engine';
import { Archetype, FearConfig, GameState } from './game/types';

const FEAR_DB: Record<string, FearConfig> = {
  'anxiety': { 
    name: 'ANXIETY', archetype: Archetype.ANXIETY, color: '#ffff00', spawnRateMod: 1.5,
    traits: { aggression: 0.4, impulsiveness: 0.9, persistence: 0.3, awareness: 0.8, cowardice: 0.4, control: 0.2, attachment: 0.3, panicResponse: 0.9, drainIntensity: 0.2 }
  },
  'depression': { 
    name: 'DEPRESSION', archetype: Archetype.DEPRESSION, color: '#0000ff', spawnRateMod: 0.8,
    traits: { aggression: 0.2, impulsiveness: 0.1, persistence: 0.9, awareness: 0.2, cowardice: 0.1, control: 0.5, attachment: 0.8, panicResponse: 0.2, drainIntensity: 0.9 }
  },
  'anger': { 
    name: 'ANGER', archetype: Archetype.ANGER, color: '#ff0000', spawnRateMod: 1.2,
    traits: { aggression: 1.0, impulsiveness: 0.6, persistence: 0.7, awareness: 0.4, cowardice: 0.0, control: 0.1, attachment: 0.5, panicResponse: 0.5, drainIntensity: 0.1 }
  },
};

const App = () => {
  const [gameState, setGameState] = useState<GameState>(GameState.INTRO);
  const [inputValue, setInputValue] = useState('');
  const [isManifesting, setIsManifesting] = useState(false);
  const [score, setScore] = useState(0);
  const [selectedFear, setSelectedFear] = useState<FearConfig | null>(null);
  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<GameEngine | null>(null);

  useEffect(() => {
    if (gameState === GameState.INTRO) {
      const timer = setTimeout(() => setGameState(GameState.FEAR_SELECTION), 2000);
      return () => clearTimeout(timer);
    }
  }, [gameState]);

  const startGame = (fear: FearConfig) => {
    setSelectedFear(fear);
    setGameState(GameState.PLAYING);
  };

  const handleFearSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;
    const key = inputValue.toLowerCase().trim();
    if (FEAR_DB[key]) { startGame(FEAR_DB[key]); return; }

    setIsManifesting(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Architect a fear profile for: "${key}". Map to traits (0-1): Aggression, Impulsiveness, Persistence, Awareness, Cowardice, Control, Attachment, PanicResponse, DrainIntensity. Choose archetype from: ANXIETY, DEPRESSION, ANGER, OVERTHINKING, LONELINESS, ADDICTION. Output JSON only.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              color: { type: Type.STRING },
              aggression: { type: Type.NUMBER },
              impulsiveness: { type: Type.NUMBER },
              persistence: { type: Type.NUMBER },
              awareness: { type: Type.NUMBER },
              cowardice: { type: Type.NUMBER },
              control: { type: Type.NUMBER },
              attachment: { type: Type.NUMBER },
              panicResponse: { type: Type.NUMBER },
              drainIntensity: { type: Type.NUMBER },
              archetype: { type: Type.STRING }
            },
            required: ["name", "color", "aggression", "impulsiveness", "persistence", "awareness", "cowardice", "control", "attachment", "panicResponse", "drainIntensity", "archetype"]
          }
        }
      });
      const data = JSON.parse(response.text);
      startGame({
        name: data.name.toUpperCase(), color: data.color, archetype: (data.archetype as Archetype) || Archetype.UNKNOWN, spawnRateMod: 1.0,
        traits: { aggression: data.aggression, impulsiveness: data.impulsiveness, persistence: data.persistence, awareness: data.awareness, cowardice: data.cowardice, control: data.control, attachment: data.attachment, panicResponse: data.panicResponse, drainIntensity: data.drainIntensity }
      });
    } catch (err) {
      startGame(FEAR_DB['anger']);
    } finally { setIsManifesting(false); }
  };

  useEffect(() => {
    if (gameState === GameState.PLAYING && canvasRef.current && selectedFear) {
      engineRef.current = new GameEngine(canvasRef.current, selectedFear, (finalScore) => { setScore(finalScore); setGameState(GameState.GAME_OVER); });
      engineRef.current.start();
      return () => engineRef.current?.stop();
    }
  }, [gameState, selectedFear]);

  if (gameState === GameState.INTRO) return <div style={{ color: '#fff', fontSize: '3.5rem', letterSpacing: '1.2rem', textAlign: 'center', textShadow: '0 0 20px #f00' }}>INNER HELL</div>;

  if (gameState === GameState.FEAR_SELECTION) return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '2rem', zIndex: 20, background: 'rgba(5,0,0,0.98)', padding: '5rem', border: '4px solid #300', boxShadow: '0 0 100px #600' }}>
      <h1 style={{ margin: 0, fontSize: '4.5rem', color: '#f00', textShadow: '0 0 35px #f00', letterSpacing: '-2px' }}>CONFRONT THE VOID</h1>
      <form onSubmit={handleFearSubmit} style={{ display: 'flex', gap: '1.5rem', width: '100%', maxWidth: '800px' }}>
        <input disabled={isManifesting} autoFocus type="text" value={inputValue} onChange={(e) => setInputValue(e.target.value)} placeholder={isManifesting ? "MANIFESTING DEMON..." : "NAME YOUR NIGHTMARE..."}
          style={{ background: 'transparent', border: 'none', borderBottom: '4px solid #800', color: '#fff', fontFamily: 'inherit', fontSize: '2.2rem', flex: 1, padding: '1rem', outline: 'none', textTransform: 'uppercase' }} />
        <button type="submit" disabled={isManifesting} style={{ background: '#900', color: '#fff', border: 'none', fontFamily: 'inherit', fontSize: '1.8rem', padding: '0 4rem', cursor: 'pointer', fontWeight: 'bold' }}>{isManifesting ? "..." : "PURGE"}</button>
      </form>
      <div style={{ display: 'flex', gap: '1rem', marginTop: '2rem' }}>
          {Object.entries(FEAR_DB).map(([id, fear]) => (
              <button key={id} onClick={() => startGame(fear)} style={{ background: 'transparent', border: `1px solid ${fear.color}`, color: fear.color, padding: '0.5rem 1.5rem', cursor: 'pointer', fontSize: '1rem', opacity: isManifesting ? 0.3 : 1 }}>{fear.name}</button>
          ))}
      </div>
    </div>
  );

  if (gameState === GameState.GAME_OVER) return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '2rem', zIndex: 20 }}>
      <h1 style={{ fontSize: '7rem', color: '#900', margin: 0, letterSpacing: '-8px', textShadow: '0 0 40px #f00' }}>EXTINGUISHED</h1>
      <div style={{ fontSize: '3.5rem', color: '#fff' }}>TOTAL WILLPOWER: {score}</div>
      <button onClick={() => setGameState(GameState.FEAR_SELECTION)} style={{ background: '#fff', color: '#000', border: 'none', fontSize: '2.5rem', padding: '1rem 6rem', cursor: 'pointer', fontWeight: 'bold' }}>REAWAKEN</button>
    </div>
  );

  return (
    <>
      <canvas ref={canvasRef} style={{ display: 'block', width: '100vw', height: '100vh', imageRendering: 'pixelated' }} />
      <div style={{ position: 'fixed', top: '10px', right: '20px', color: '#f00', fontSize: '1.5rem', fontWeight: 'bold', textShadow: '0 0 10px #000' }}>[1-5] ARSENAL</div>
    </>
  );
};

const container = document.getElementById('root');
const root = createRoot(container!);
root.render(<App />);